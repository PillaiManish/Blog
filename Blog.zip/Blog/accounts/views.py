from django.shortcuts import render,redirect
from django.contrib.auth.models import auth,User
from blog.models import Category


# Create your views here.
def f_login(request):
    if request.user.is_authenticated:
        return redirect('/')
    
    else:
        if request.method == 'POST':
            username = request.POST['username']
            password = request.POST['password']

            check_user = auth.authenticate(username=username,password=password)

            if check_user is not None:
                auth.login(request,check_user)
                return redirect('/')


        
        category = Category.objects.all()
        return render(request,'loginpage.html',{'category':category})

def f_logout(request):
    if request.user.is_authenticated:            
        auth.logout(request)
        return redirect('/')
    return redirect('/account/login')


def f_register(request):
    if request.user.is_authenticated:
        return redirect('/')
            
    else:
        if request.method == 'POST':
            username = request.POST['username']
            fname = request.POST['fname']
            lname = request.POST['lname']
            email = request.POST['email']
            password = request.POST['password']


            new_user = User.objects.create_user(username=username,first_name=fname,last_name=lname,password=password,email=email)
            new_user.save()

            return redirect('/account/login')



        
        category = Category.objects.all()
        
        return render(request,'registerpage.html',{'category':category})