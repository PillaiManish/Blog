from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from .models import Blog,Category,Comments

# Create your views here.
def f_newblog(request):
    category = Category.objects.all()
    if request.user.is_authenticated:

        if request.method == 'POST':
            username = request.user.username
            subject = request.POST['subject']
            content = request.POST['content']
            category_user = request.POST['category']




            category_count = Blog.objects.filter(category=category_user).count()



            newblog = Blog(username_id=username,subject=subject,content=content,category=category_user)
            newblog.save()

            try:
                category_number = Category.objects.get(category_type=category_user)
                category_number.total_number = category_count +1
                category_number.save()
            except:
                new_category = Category(category_type = category_user,total_number=1)
                new_category.save()



            return redirect('/')

        return render(request,'newblog.html',{'category':category})
    
    return redirect('/account/login') # if user not login redirect to login page


def f_blog_sort(request,id):
    if request.method=='POST':


        
        try:
            if request.POST['like']=='like':
                like_id = id
                blog_like = Blog.objects.get(id=like_id)
                blog_like.likes = blog_like.likes +1
                blog_like.save()


        except:
            if request.POST['comments']=='Submit':

                comment = request.POST['comment']
                username = request.user.username
                blog_id = id

                new_comment = Comments(username_id=username,blog_id_id=id,comment=comment)
                new_comment.save()





    category = Category.objects.all()
    comments = Comments.objects.filter(blog_id=id).order_by('-date')
    blog_sort = Blog.objects.filter(id=id)
    return render(request,"readmore_page.html",{'data':blog_sort,'comments':comments,'category':category})



def f_blog_category(request,category):


    blog_sort = Blog.objects.filter(category=category).order_by('-date')
    category = Category.objects.all()
    return render(request,"homepage.html",{'data':blog_sort,'category':category})


