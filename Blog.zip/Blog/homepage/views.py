from django.shortcuts import render
from blog.models import Blog,Category,Comments
from .models import CompanyData
from django.db.models import Q

# Create your views here.
def f_homepage(request):
# one user on likes problem


    category = Category.objects.all()
    blog = Blog.objects.order_by('-date')
    most_like_blog = Blog.objects.order_by('-likes').first()
    company_info = CompanyData.objects.all().first()


    if request.method == 'POST':
        try:
            if request.POST['search'] == 'search':
                search =request.POST['user_search']
                blog = Blog.objects.filter(content__icontains=search)
                return render(request,'homepage.html',{'data':blog,'category':category,'most_like':most_like_blog,'company':company_info})
        
        
        except:
            like_id = request.POST['like']
            blog_like = Blog.objects.get(id=like_id)
            blog_like.likes = blog_like.likes +1
            blog_like.save()
            return render(request,'homepage.html',{'data':blog,'category':category,'most_like':most_like_blog,'company':company_info})
   

    
    
    return render(request,'homepage.html',{'data':blog,'category':category,'most_like':most_like_blog,'company':company_info})






